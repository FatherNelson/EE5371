#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "Project/test.h"

int main() {
	test();
	return 0;
}