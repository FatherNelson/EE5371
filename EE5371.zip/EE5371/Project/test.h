//
// Created by Grant Udstrand on 2019-11-19.
//

#ifndef EE5371_TEST_H
#define EE5371_TEST_H

#include "test.cpp"

int test();

#endif //EE5371_TEST_H
