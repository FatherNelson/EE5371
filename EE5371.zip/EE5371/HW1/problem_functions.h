//
// Created by Grant Udstrand on 2019-09-21.
//

#ifndef EE5371_PROBLEM_FUNCTIONS_H
#define EE5371_PROBLEM_FUNCTIONS_H

#include "problem_functions.cpp"

void end(FILE* fp, char* A, char* B);
void test();

#endif //EE5371_PROBLEM_FUNCTIONS_H
