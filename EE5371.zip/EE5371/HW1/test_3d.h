//
// Created by Grant Udstrand on 2019-09-22.
//

#ifndef EE5371_TEST_3D_H
#define EE5371_TEST_3D_H

#include "test_3d.cpp"

int timer();

#endif //EE5371_TEST_3D_H
