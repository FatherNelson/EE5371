//
// Created by Grant Udstrand on 2019-09-22.
//

#ifndef EE5371_TEST_3C_H
#define EE5371_TEST_3C_H

#include "test_3c.cpp";

int timer();

#endif //EE5371_TEST_3C_H
