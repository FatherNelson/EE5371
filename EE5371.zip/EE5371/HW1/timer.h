//
// Created by Grant Udstrand on 2019-09-21.
//

#ifndef EE5371_TIMER_H
#include "timer.cpp"

int timer(int argc, char *argv[]);

#define EE5371_TIMER_H

#endif //EE5371_TIMER_H
