//
// Created by Grant Udstrand on 2019-11-17.
//

#ifndef EE5371_SPEEDTEST_H
#define EE5371_SPEEDTEST_H

#include "speedtest.cpp"

int speedtest();

#endif //EE5371_SPEEDTEST_H
